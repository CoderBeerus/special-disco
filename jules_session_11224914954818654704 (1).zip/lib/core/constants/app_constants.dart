class AppConstants {
  static const String appName = 'Calibrix';
  static const int maxBrowserTabs = 5;
  static const Duration controlsAutoHide = Duration(seconds: 3);
  static const Duration mediaDetectionThrottle = Duration(milliseconds: 250);
}
